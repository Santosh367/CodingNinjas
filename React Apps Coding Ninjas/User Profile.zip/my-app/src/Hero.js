import React from "react";

const Hero = () => {
  return (
    // <div className="hero">
    //   <h4>Name: John Doe</h4>
    //   <p>Email: johndoe@example.com</p>
    //   <p>Phone: +1234567890</p>
    //   <p>Address: 123 Main Street, City, Country</p>
    // </div>

    <div className="hero">
      <ul>
        <li><h4>Name: John Doe</h4></li>
        <li><p>Email: johndoe@example.com</p></li>
        <li><p>Phone: +1234567890</p></li>
        <li><p>Address: 123 Main Street, City, Country</p></li>
      </ul>
    </div>

  );
};

export default Hero;
