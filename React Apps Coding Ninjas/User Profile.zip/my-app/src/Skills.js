import React from "react";

const Skills = () => {
  return (
    <div className="skills">
      <p>HTML</p>
      <p>CSS</p>
      <p>JavaScript</p>
      <p>React</p>
      <p> Node.js </p>
    </div>
  );
};

export default Skills;
