import React from "react";

const About = () => {
  return (
    <div className="about">
      <p>
        I am a web developer with experience in frontend technologies. In my free time, I enjoy working on personal projects and exploring new technologies. I have worked on various web development projects and I am passionate about creating user-friendly and visually appealing web applications.
      </p>
    </div>
  );
};

export default About;

