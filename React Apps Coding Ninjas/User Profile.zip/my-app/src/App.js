import React from "react";
import Hero from "./Hero";
import Skills from "./Skills";
import About from "./About";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <Hero />
      <Skills />
      <About />
    </div>
  );
}
