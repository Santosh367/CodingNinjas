import React from "react";
import { name, email } from "./HomePage";

const Form = () => {
  const handleSubmit = (event) => {
    event.preventDefault(); 
  };

  return (
    <>
      <div>
        <form onSubmit={handleSubmit}>
          <h3>Login Page</h3>
          <input type="text" value={name} placeholder="Name" />
          <br />
          <br />
          <input type="text" value={email} placeholder="Email" />
          <br />
          <br />
          <button type="submit">Login</button>
        </form>
      </div>
    </>
  );
};

export default Form;
