import React from "react";
import Form from "./Form";

export const name = "YourName";
export const email = "xyz@pqr.com";

function HomePage() {
  return (
    <div className="Homepage">
      <h1>HomePage</h1>
      <Form />
    </div>
  );
}

export default HomePage;
