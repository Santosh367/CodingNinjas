import styles from "./App.module.css";
import List from "./List";

export default function App() {
  return (
    <div className={styles.app}>
      <h3 className={styles.title}>Ecommerce Store</h3>
      <List />
    </div>
  );
}
