import React from "react";
import ImageList from "./components/ImageList";
import "./styles.css";

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      images: [],
      imageUrl: ""
    };
  }

  componentDidMount() {
    const images = this.getImagesFromLS();
    this.setState({ images });
  }

  addImageToLS = (e) => {
    e.preventDefault();

    if (this.state.imageUrl.trim().length < 5) {
      return;
    }

    const newImage = this.state.imageUrl;
    const updatedImages = [...this.state.images, newImage];

    localStorage.setItem("images", JSON.stringify(updatedImages));
    this.setState({ images: updatedImages, imageUrl: "" });
  };

  getImagesFromLS = () => {
    const images = localStorage.getItem("images");
    if (!images) {
      localStorage.setItem("images", JSON.stringify([]));
      return [];
    }
    return JSON.parse(images);
  };

  handleImageUrlChange = (e) => {
    this.setState({ imageUrl: e.target.value });
  };

  render() {
    return (
      <div className="App">
        <form onSubmit={this.addImageToLS}>
          <input
            type="text"
            placeholder="Image URL"
            value={this.state.imageUrl}
            onChange={this.handleImageUrlChange}
          />
          <button type="submit">Add Image</button>
        </form>
        <ImageList images={this.state.images} />
      </div>
    );
  }
}
