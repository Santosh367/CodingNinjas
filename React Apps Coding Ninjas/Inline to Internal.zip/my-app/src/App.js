import "./styles.css";

const formStyles = {
  width: "60%",
  margin: "50px auto",
  display: "flex",
  flexDirection: "column",
  gap: 20,
};

const inputStyles = {
  padding: 10,
};

const buttonStyles = {
  outline: "none",
  paddingBlock: 5,
  width: 100,
  backgroundColor: "red",
  color: "white",
  cursor: "pointer",
};

export default function App() {
  return (
    <div className="App">
      <form style={formStyles}>
        <h3 style={{ fontSize: "2rem", letterSpacing: 2 }}>Sign Up</h3>
        <input style={inputStyles} placeholder="Username" />
        <input style={inputStyles} placeholder="Email" />
        <input style={inputStyles} placeholder="Password" />
        <div style={{ display: "flex", justifyContent: "center", gap: 20 }}>
          <button style={buttonStyles}>Cancel</button>
          <button style={buttonStyles}>Login</button>
        </div>
      </form>
    </div>
  );
}
