import React from "react";
import { instructors } from "../data";
import "../styles.css";

export default class Sidebar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      following: []
    };
  }

  handleFollow = (id) => {
    const instructor = instructors.find((inst) => inst.id === id);
    this.setState((prevState) => ({
      following: [...prevState.following, instructor]
    }));
  };

  handleUnfollow = (id) => {
    this.setState((prevState) => ({
      following: prevState.following.filter((inst) => inst.id !== id)
    }));
  };

  render() {
    const { following } = this.state;

    return (
      <div className="sidebar">
        {instructors.map((instructor) => (
          <div key={instructor.id} className="instructor">
            <img src={instructor.image} alt={instructor.name} />
            <h3>{instructor.name}</h3>
            <button
              onClick={() =>
                following.some((inst) => inst.id === instructor.id)
                  ? this.handleUnfollow(instructor.id)
                  : this.handleFollow(instructor.id)
              }
            >
              {following.some((inst) => inst.id === instructor.id)
                ? "Unfollow"
                : "Follow"}
            </button>
          </div>
        ))}
      </div>
    );
  }
}
