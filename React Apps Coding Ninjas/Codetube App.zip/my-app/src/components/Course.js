import React from "react";

export default function Course({ course, onAdd, onRemove, isInBag }) {
  const { id, title, description, image, instructor, price } = course;

  return (
    <div className="course">
      <img src={image} alt={title} />
      <div>
        <h3>{title}</h3>
        <p>{description}</p>
        <p>{instructor}</p>
        <strong>{price}</strong>
        <button onClick={() => (isInBag ? onRemove(id) : onAdd(id))}>
          {isInBag ? "Remove from bag" : "Add to bag"}
        </button>
      </div>
    </div>
  );
}
