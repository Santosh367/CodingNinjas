import React from "react";
import Course from "./components/Course";
import { courses } from "./data";
import "./styles.css";

export default class List extends React.Component {
  render() {
    const { onAdd, onRemove, bagItems } = this.props;

    return (
      <div className="list">
        {courses.map((course) => (
          <Course
            key={course.id}
            course={course}
            onAdd={onAdd}
            onRemove={onRemove}
            isInBag={bagItems.some((item) => item.id === course.id)}
          />
        ))}
      </div>
    );
  }
}
