import "./styles.css";
import React from "react";
import List from "./List";
import Sidebar from "./components/Sidebar";
import Navbar from "./components/Navbar";
import { courses } from "./data";

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      bagItems: []
    };
  }

  handleAddToBag = (id) => {
    const item = courses.find((course) => course.id === id);
    this.setState((prevState) => ({
      bagItems: [...prevState.bagItems, item]
    }));
  };

  handleRemoveFromBag = (id) => {
    this.setState((prevState) => ({
      bagItems: prevState.bagItems.filter((item) => item.id !== id)
    }));
  };

  render() {
    return (
      <div className="App">
        <Navbar bagItems={this.state.bagItems} />
        <h3>CodeTube Catalog</h3>
        <div className="container">
          <List
            onAdd={this.handleAddToBag}
            onRemove={this.handleRemoveFromBag}
            bagItems={this.state.bagItems}
          />
          <Sidebar />
        </div>
      </div>
    );
  }
}
