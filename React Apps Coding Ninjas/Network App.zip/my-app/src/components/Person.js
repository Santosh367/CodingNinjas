import { Component } from "react";

class Person extends Component {
  render() {
    const { img, email, show } = this.props.person;

    if (!show) {
      return null; // Do not render if show is false
    }

    return (
      <div className="person">
        <b onClick={this.props.removePerson}>X</b>
        <img alt={email} src={img} role="img" />
        <p>{email}</p>
      </div>
    );
  }
}

export default Person;
