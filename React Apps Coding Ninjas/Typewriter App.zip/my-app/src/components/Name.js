import React from "react";

export default class Name extends React.Component {
  constructor() {
    super();
    this.state = {
      fullName: "Coding Ninjas",
      curIndex: 0,
      currentName: ""
    };
    this.timerID = null;
  }

  componentDidUpdate(prevProps) {
    if (prevProps.showName !== this.props.showName) {
      if (this.props.showName) {
        if (this.state.curIndex === this.state.fullName.length) {
          this.setState({ curIndex: 0 });
        }
        this.timerID = setInterval(this.typeWriterEffect, 500);
      } else {
        clearInterval(this.timerID);
      }
    }
  }

  componentWillUnmount() {
    clearInterval(this.timerID);
  }

  typeWriterEffect = () => {
    this.setState((prevState) => {
      const { fullName, curIndex } = prevState;
      const nextIndex = curIndex + 1;
      const currentName = fullName.substring(0, nextIndex);

      if (nextIndex === fullName.length) {
        clearInterval(this.timerID);
      }

      return {
        curIndex: nextIndex,
        currentName
      };
    });
  };

  render() {
    return <h1>{this.state.currentName}</h1>;
  }
}
